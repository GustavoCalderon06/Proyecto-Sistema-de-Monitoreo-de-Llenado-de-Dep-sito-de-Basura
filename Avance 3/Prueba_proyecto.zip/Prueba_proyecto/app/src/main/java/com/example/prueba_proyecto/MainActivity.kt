package com.example.prueba_proyecto
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.AsyncTask
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var tvNivel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnConsultar: Button = findViewById(R.id.btnConsultar)
        tvNivel = findViewById(R.id.tvNivel)

        btnConsultar.setOnClickListener {
            ConsultarNivelTask().execute()
        }
    }

    private inner class ConsultarNivelTask : AsyncTask<Void, Void, String>() {
        override fun doInBackground(vararg params: Void?): String? {
            return try {
                val url = URL("http://52.200.139.211:5000/api/last_data")
                val urlConnection = url.openConnection() as HttpURLConnection
                try {
                    val bufferedReader = BufferedReader(InputStreamReader(urlConnection.inputStream))
                    val stringBuilder = StringBuilder()
                    var line: String?
                    while (bufferedReader.readLine().also { line = it } != null) {
                        stringBuilder.append(line).append("\n")
                    }
                    bufferedReader.close()
                    stringBuilder.toString()
                } finally {
                    urlConnection.disconnect()
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error fetching data", e)
                null
            }
        }

        override fun onPostExecute(response: String?) {
            response?.let {
                try {
                    val jsonObject = JSONObject(it)
                    val nivelLlenado = jsonObject.getDouble("nivelLlenado")
                    tvNivel.text = "Nivel de Llenado: $nivelLlenado%"
                } catch (e: Exception) {
                    Log.e("MainActivity", "Error parsing JSON", e)
                }
            } ?: run {
                Log.e("MainActivity", "Response is null")
            }
        }
    }
}
